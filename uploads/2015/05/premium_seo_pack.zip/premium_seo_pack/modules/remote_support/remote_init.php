<?php
$aa_tunnel_config = array(
	"key" => "501d0292aca8270d539662a5a9aad855",
	"url" => "http://dev.premiumseopack.com/wp-content/plugins/premium-seo-pack/modules/remote_support/remote_tunnel.php",
	"path"=> "/home/aateam30/public_html/premiumseopack.com/dev/"
);