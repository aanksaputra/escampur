DreamHost PHP.INI installer
Copyright (c) 2008 Shayne Burley
All Rights Reserved.
email: sxi@sabrextreme.com
web: http://sxi.sabrextreme.com
forum: http://sxi.sabrextreme.com/forum


INSTRUCTIONS:

Upload dh-phpini.php into your domain's folder and open it in a browser.


------------------------------------------------

Was this script useful? Consider donating! =)

Paypal: sxi@sabrextreme.com

------------------------------------------------


DreamHost is a registered trademark of New Dream Network, LLC

Copyright (c) 2008 Shayne Burley

http://sxi.sabrextreme.com